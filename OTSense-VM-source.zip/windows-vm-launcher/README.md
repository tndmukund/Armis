# OT Sense VM app (Windows)

A normal Windows program cannot send real ARP requests or read MAC addresses. This app runs the OT Sense **Linux sensor** inside a small virtual machine on the
Windows PC, connected to the Wi-Fi or cable adapter the user picks. The sensor then scans that network with real ARP and sees MAC addresses and vendors.

## For the person at the site (non-IT)
1. Download the ONE zip from the link you were given (about 300 MB). Right-click > **Extract All**.
2. Double-click **OTSense-VM.exe**. Click **Yes** at the Windows question. (If Windows says "protected your PC": More info > Run anyway.)
3. Your Wi-Fi is already selected. Press the big green **START**. After 1-3 minutes the site turns green in central. Press **STOP** when finished.

Everything else is optional: Passive/Active scanning, "stop automatically after N minutes", "start when I sign in to Windows", "start as soon as this window opens",
Test connection to central, Open sensor page, Show VM screen (Hyper-V), Remove VM.
If the PC has no VM software the window shows one button: **Turn on Hyper-V** (Windows Pro/Enterprise, one restart) or **Install VirtualBox** (free, automatic, any Windows).

## For you, once (administrator) - GitHub steps, all in a phone browser
1. In your GitHub repository: **Add file > Upload files** and upload `OTSense-VM-source.zip` (do not unzip it).
2. **Add file > Create new file**, name it `.github/workflows/build-vm-app.yml`, paste the text of `build-vm-app.yml`, **Commit changes**.
3. **Actions > Build OT Sense VM app > Run workflow**. Wait 3-5 minutes for the green tick.
4. **Releases** > the newest `vm-...` release > long-press `OTSense-VM.exe` > **Copy link address** (the repository must be Public).
5. In central: **Sites tab > Base images box > choose "Windows VM app" > paste the link > Import from link.**
6. **Add site and build sensor**, platform **Windows PC - Linux VM app, ONE zip**, press Build, download the zip and give it to the site person.

## Notes
- The sensor ISO (base image) must also be on the server (Base images box shows it). The zip given to the site contains the exe + this site's ISO + settings.
- Hyper-V creates a virtual switch on the chosen adapter: the PC loses Wi-Fi for a few seconds, and some routers refuse the extra device on Wi-Fi. VirtualBox bridges Wi-Fi more smoothly; with a cable both are reliable.
- Scanning (Passive/Active) is written into the site's ISO copy by the app before each START (the VM must be stopped). Central's per-site setting still overrides it.
- Settings are remembered in `vm-settings.json` next to the exe. `python otsense_vm.py --selftest` checks the command builders without a VM or a window.
- NOT tested on a real Windows PC with Hyper-V/VirtualBox in the environment where this was written: do one trial run before rolling out.
